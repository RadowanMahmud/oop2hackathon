package sample;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class studentlogin {

    private String username;
    private String password;

    Student studentarr[]=new Student[3];

    public studentlogin(String username,String password)
    {
        this.username=username;
        this.password=password;
    }

    private String filename= "src/logininfo.txt";


    public boolean trylogin() {
        boolean chk=false;
        try {
            Scanner cin = new Scanner(new File(filename));

            for (int i = 0; i <= 2; i++)
            {
                studentarr[i]=new Student();
                studentarr[i].name = cin.next();
                studentarr[i].password = cin.next();
                if (username.equals(studentarr[i].name) && password.equals(studentarr[i].password))
                {
                   chk=true;
                   break;
                }
            }
        }
        catch (Exception ex) {
            Logger.getLogger(studentlogin.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally {
            return chk;
        }



    }
}

