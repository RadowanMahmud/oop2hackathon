package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXML;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Afterlogin {

    @FXML
    TextField accountnumber;
    @FXML
    TextField amount;
    @FXML
    AnchorPane rootpane1;
    public void socket(ActionEvent e1)
    {
        if (amount.getText().equals("100")) {
            try {
                Socket s = new Socket("localhost", 3333);

                DataInputStream din = new DataInputStream(s.getInputStream());
                DataOutputStream dout = new DataOutputStream(s.getOutputStream());
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

                String account;
                String reply;
                String am;
                account = accountnumber.getText();

                dout.writeUTF(account);
                dout.flush();
                System.out.println(accountnumber.getText());

                reply = din.readUTF();
                if(reply.equals("permission given"))
                {
                    try{
                        Parent root = FXMLLoader.load(getClass().getResource("/sample/application.fxml"));
                        Scene scene = new Scene(root);
                        Stage currWindow = (Stage) rootpane1.getScene().getWindow();
                        currWindow.setScene(scene);
                        currWindow.show();
                    }
                    catch (Exception ex) {
                        Logger.getLogger(Afterlogin.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                else System.out.println(reply);
                dout.close();
                s.close();
            } catch (Exception ex) {
                Logger.getLogger(Afterlogin.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

    }

}
