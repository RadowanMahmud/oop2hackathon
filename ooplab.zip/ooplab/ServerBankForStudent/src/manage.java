public class manage {

   public String operation(String account)
   {
       Account studentaccount[]=new Account[6];

       studentaccount[0]= new Account("1001",500);
       studentaccount[1]= new Account("1002",500);
               studentaccount[2]= new Account("1002",500);
       studentaccount[3]= new Account("1002",500);
               studentaccount[4]= new Account("1002",500);
       studentaccount[5]= new Account("1002",500);

       for(int i=0;i<6;i++)
       {
           if(account.equals(studentaccount[i].account))
           {
               if(studentaccount[i].getBalance()>100)
               {
                   studentaccount[i].setbalance(100);
                   return "permission given";
               }
           }

       }

       return "no money";
   }

}
