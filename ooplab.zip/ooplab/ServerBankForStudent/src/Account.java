public class Account {

    String account;
    double balance;

    public Account(String account,double balance)
    {
       this.account=account;
       this.balance=balance;
    }


    public double getBalance(){
        return this.balance;
    }

    public void setbalance(double amount){
        this.balance=this.balance-amount;
    }


}