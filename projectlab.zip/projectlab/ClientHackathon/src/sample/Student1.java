package sample;

import java.io.Serializable;

public class Student1 implements Serializable {
    String name;
    transient String university;
    double weight;

    protected static int number_Of_DU_students = 0;

    public Student1() {

        this("Unknown", "Unknown", 0.0);
    }

    public Student1(String name, String university, double weight) {
        this.name = name;
        this.university = university;
        this.weight = weight;

        if (university.equalsIgnoreCase("DU"))
            number_Of_DU_students++;

    }

    public void printName(){
        System.out.println("Hello " + this.name);
    }

    public static int getNumberOfDUStudents(){
        return number_Of_DU_students;
    }

}
