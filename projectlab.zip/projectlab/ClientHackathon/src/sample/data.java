package sample;

public class data {

    public static String roll;
}
