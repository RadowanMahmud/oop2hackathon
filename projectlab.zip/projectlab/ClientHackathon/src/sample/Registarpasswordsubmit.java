package sample;

import javafx.fxml.FXML;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Registarpasswordsubmit implements Initializable {

    @FXML
    TextField user;
    @FXML
    TextField password;
    @FXML
    TextField confirm;
    @FXML
    AnchorPane pop;
    @FXML
    AnchorPane registersubmit;
    @FXML
    Button retry;

    public void registar(ActionEvent e) throws IOException{
             String username=user.getText();
             String myPassword=password.getText();
             String confirmpass=confirm.getText();

             if(!myPassword.equals(confirmpass))
             {
                   pop.setVisible(true);
                   retry.setOnAction(eq->{
                       pop.setVisible(false);
                   });
             }
             else
             {
                 FileOutputStream fout=new FileOutputStream(new File("src/logininfo.txt"),true);
                 String str=username+" "+myPassword+"\n";
                 fout.write(str.getBytes());
                 fout.close();

                 try{
                     Parent root = FXMLLoader.load(getClass().getResource("/sample/sample.fxml"));
                     Scene scene = new Scene(root);
                     Stage currWindow = (Stage) registersubmit.getScene().getWindow();
                     currWindow.setScene(scene);
                     currWindow.show();
                 }
                 catch (Exception ex) {
                     Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
                 }
             }

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        pop.setVisible(false);
    }
}
