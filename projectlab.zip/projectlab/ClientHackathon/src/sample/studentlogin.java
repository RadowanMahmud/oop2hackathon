package sample;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class studentlogin {

    private String username;
    private String password;

    Student studentarr[]=new Student[3];

    public studentlogin(String username,String password)
    {
        this.username=username;
        this.password=password;
    }

    private String filename= "src/logininfo.txt";


    public boolean trylogin() {

        if(username.isEmpty() || password.isEmpty()) return false;
        else if(username==null || password==null) return false;
        try {
            Scanner cin = new Scanner(new File(filename));

            for (;cin.hasNextLine();)
            {
                String inf=cin.nextLine();
                String str[]=inf.split(" ");
                if (username.equals(str[0]) && password.equals(str[1]))
                {
                   return true;
                }
            }
        }
        catch (Exception ex) {
            Logger.getLogger(studentlogin.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }

        return false;


    }
}

