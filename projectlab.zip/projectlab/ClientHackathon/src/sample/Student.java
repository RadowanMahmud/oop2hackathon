package sample;

import java.io.Serializable;

public class Student implements Serializable {
    String name;
    String password;


    public Student() {

    }

    public Student(String name, String password) {
        this.name = name;
        this.password = password;

    }

    public void printName(){
        System.out.println("Hello " + this.name);
    }

    public String getname(){
        return name;
    }


}
