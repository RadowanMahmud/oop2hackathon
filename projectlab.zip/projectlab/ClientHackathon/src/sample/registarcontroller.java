package sample;

import javafx.fxml.FXML;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class registarcontroller {

    @FXML
    TextField name;
    @FXML
    TextField roll;
    @FXML
    TextField year;
    @FXML
    AnchorPane registar;

    public void submit(ActionEvent e) throws IOException {

        String sname= name.getText();
        String sroll= roll.getText();
        String syear= year.getText();

        if(sname.isEmpty() || sroll.isEmpty() || syear.isEmpty())
        {
            return ;
        }

        File folder = new File("src/student/");

        File files[] = folder.listFiles();

        if(files!=null) {
            for (File f : files) {
                if(f.getName().equals(sroll))
                    return;
            }
        }

        FileOutputStream fout = new FileOutputStream("src/student/" + sroll);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fout);


        Studentdata s=new Studentdata(sname,sroll,syear);
        objectOutputStream.writeObject(s);



        try{
            Parent root = FXMLLoader.load(getClass().getResource("/sample/registarpasswordsubmit.fxml"));
            Scene scene = new Scene(root);
            Stage currWindow = (Stage) registar.getScene().getWindow();
            currWindow.setScene(scene);
            currWindow.show();
        }
        catch (Exception ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
