package sample;

import java.io.Serializable;

public class Studentdata implements Serializable {

    String name;
    String roll;
    String year;


    public Studentdata(String name,String roll,String year) {
       this.name=name;
       this.roll=roll;
       this.year=year;
    }

}
