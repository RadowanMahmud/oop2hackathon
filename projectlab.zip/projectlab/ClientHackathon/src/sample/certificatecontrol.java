package sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXML;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.net.URL;
import java.util.ResourceBundle;

public class certificatecontrol implements Initializable {
    @FXML
    TextField name;
    @FXML
    TextField broll;
    @FXML
    TextField year;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        System.out.println("test1");

        try{
            System.out.println("test2");
            System.out.println(data.roll);
            FileInputStream fin = new FileInputStream(new File("/home/ubuntu/IdeaProjects/ClientHackathon/src/student/" + data.roll));
            ObjectInputStream op=new ObjectInputStream(fin);
            Studentdata s= (Studentdata) op.readObject();
            System.out.println(s.name);
            name.setText(s.name);
            broll.setText(s.roll);
            year.setText(s.year);

        }
        catch (Exception e){

        }
    }
}
