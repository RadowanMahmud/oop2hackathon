package sample;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXML;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;



public class applicationcontrol{

    @FXML
    TextField roll;
    @FXML
    AnchorPane vairevai;


    public void submit(ActionEvent e) {

       String rll =roll.getText();

       if(rll.isEmpty()) return;;

        File folder = new File("src/student/");

        File files[] = folder.listFiles();

        if (files != null) {
            for (File f : files) {
                if (f.getName().equals(rll)) {
                    data.roll = rll;

                    try{
                        Parent root = FXMLLoader.load(getClass().getResource("/sample/certificate.fxml"));
                        Scene scene = new Scene(root);
                        Stage currWindow = (Stage) vairevai.getScene().getWindow();
                        currWindow.setScene(scene);
                        currWindow.show();
                    }
                    catch (Exception ex) {
                        Logger.getLogger(Afterlogin.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
            return;
        }
    }

}
