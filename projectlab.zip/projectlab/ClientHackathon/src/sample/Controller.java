package sample;

import javafx.fxml.FXML;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Controller {

    @FXML
    TextField name;
    @FXML
    TextField pass;
    @FXML
    GridPane rootpane;
    public void  login (ActionEvent e)
    {
          String s=name.getText();
          String s1=pass.getText();
          studentlogin mystudent=new studentlogin(s,s1);
         if(mystudent.trylogin())
          {
              try{
                  Parent root = FXMLLoader.load(getClass().getResource("/sample/afterlogin.fxml"));
                  Scene scene = new Scene(root);
                  Stage currWindow = (Stage) rootpane.getScene().getWindow();
                  currWindow.setScene(scene);
                  currWindow.show();
              }
              catch (Exception ex) {
                  Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
              }
          }
          else System.out.println("no");

    }
    public void  registar (ActionEvent e2)
    {
        try{
            Parent root = FXMLLoader.load(getClass().getResource("/sample/registration.fxml"));
            Scene scene = new Scene(root);
            Stage currWindow = (Stage) rootpane.getScene().getWindow();
            currWindow.setScene(scene);
            currWindow.show();
        }
        catch (Exception ex) {
            Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
