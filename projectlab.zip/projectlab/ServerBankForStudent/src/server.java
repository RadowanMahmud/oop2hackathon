import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class server {

    public static void main(String args[])throws Exception{
        System.out.println("welcome to server");

        ServerSocket ss=new ServerSocket(3330);
        while(true)
        {
            Socket s=ss.accept();

            DataInputStream din=new DataInputStream(s.getInputStream());
            DataOutputStream dout=new DataOutputStream(s.getOutputStream());
            BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

            String account="",reply="";
            while(!account.equals("stop")){
                account=din.readUTF();
                System.out.println(reply);

                System.out.println(account);
                manage m=new manage();
                reply=m.operation(account);
                System.out.println("server running");
                dout.writeUTF(reply);
                System.out.println(reply);


            }
            din.close();
            s.close();
            ss.close();

            System.out.println("OK from Server");


        }


    }
}

